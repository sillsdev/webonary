<?php
$defaultDomain['1.'] = __('FOODS', 'sil_dictionary');
$defaultDomain['1.1.'] = __('Cereal', 'sil_dictionary');
$defaultDomain['1.2.'] = __('Creole food', 'sil_dictionary');
$defaultDomain['1.3.'] = __('Dessert', 'sil_dictionary');
$defaultDomain['1.4.'] = __('Fish', 'sil_dictionary');
$defaultDomain['1.5.'] = __('Fruit', 'sil_dictionary');
$defaultDomain['1.6.'] = __('Meat', 'sil_dictionary');
$defaultDomain['1.7.'] = __('Puerto Rican Fritters', 'sil_dictionary');
$defaultDomain['1.8.'] = __('Seafood', 'sil_dictionary');
$defaultDomain['1.9.'] = __('Spice', 'sil_dictionary');
$defaultDomain['1.10.'] = __('Vegetables', 'sil_dictionary');
?>