<?php
include ABSPATH . 'wp-content/plugins/sil-dictionary-webonary/processes/import_entries.php';
