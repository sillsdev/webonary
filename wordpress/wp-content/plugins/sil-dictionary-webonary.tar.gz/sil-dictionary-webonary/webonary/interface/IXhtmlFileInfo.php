<?php


/**
 * Interface IXhtmlFileInfo
 *
 * @property int ID
 * @property string url
 *
 */
interface IXhtmlFileInfo
{

}
